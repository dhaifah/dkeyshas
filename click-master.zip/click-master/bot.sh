python main.py +19703232319 ltc
sh bot.sh